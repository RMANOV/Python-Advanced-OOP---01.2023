# •	In the dog.py file, create a class called Dog with a single method bark() that returns: "barking…".
# The Dog should inherit from Animal.



class Dog(Animal):
    def bark(self):
       return "barking..."


# •	In the main.py file, create a Dog object and call its bark() method.