# •	In the dog.py file, create a class called Dog with a single method bark() that returns: "barking…".
# The Dog should inherit from Animal.

from project.animal import Animal

class Dog(Animal):
    def bark(self):
       return "barking..."
